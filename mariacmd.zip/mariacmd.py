import mariadb
import sys


# Instantiate Connection
try:
   conn = mariadb.connect(
      user="",              # root
      password="",     # fill your password
      host="localhost",
      port=3306)
except mariadb.Error as e:
   print(f"Error connecting to MariaDB Platform: {e}")
   sys.exit(1)
print("database connected")


# Instantiate Cursor
cur = conn.cursor()


def terminate():
    conn.close()
    print("terminated mariadb")


# create database
def createdb(name):
    cur.execute(f"CREATE DATABASE IF NOT EXISTS {name};")
    print(f"created database {name}")


# use DATABASE
def usedb(name):
    cur.execute(f"USE {name};")
    print(f"using database {name}")


# create table
def create_table(dbname, tname, col):
    cur.execute(f'CREATE TABLE IF NOT EXISTS {dbname}.{tname}({col});')
    print(f"table {tname} created")


# drop table
def drop_table(dbname, tname):
    cur.execute(f'DROP TABLE {dbname}.{tname};')
    print(f"droped table {tname}")


# Adds row
def add_row(dbname, tname, pname, ptype, pprice):
   """Adds the given contact to the contacts table"""

   cur.execute(f'INSERT INTO {dbname}.{tname}(Pname, Ptype, Pprice) VALUES ("{pname}", "{ptype}", {pprice});')
   conn.commit()
   print("row added")


 # Print List of Contacts
def show_table(col, dbname, tname):
   """Retrieves the list of contacts from the database and prints to stdout"""

   # Initialize Variables
   contacts = []

   # Retrieve Contacts
   cur.execute(f"SELECT {col} FROM {dbname}.{tname}")

   # Prepare Contacts
   for row in cur:
      contacts.append(str(row))

   # List Contacts
   print("\n".join(contacts))
   print(f"row count : {len(contacts)}")
